print all parts at 100% infill with the suggested print orientation, 0.12mm layer height recommended
do not build/use without reinforcements
follow assembly instructions for best results
do not "ride the slide" when charging, pull charging handle back and release

a special thanks to my beta testers
unseenkiller
SwarmTech
manyenemiesbringsmuchhonor
plasticcrack
creatingreality
CarbonFiberGoth
